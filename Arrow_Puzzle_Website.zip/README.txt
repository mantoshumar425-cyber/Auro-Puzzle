ARROW PUZZLE — WEB EDITION

This is a browser-playable recreation inspired by the uploaded Arrow Puzzle APK.
It is not a direct Unity APK-to-HTML conversion and does not contain the original
Unity game engine or proprietary source code. The APK's index.html was located in
assets/iads/ and appears to belong to the ad SDK, not the game itself.

HOW TO RUN
1. Extract Arrow_Puzzle_Website.zip.
2. Open index.html in a browser, or upload the whole folder to a static host.
3. For GitHub Pages / Cloudflare Pages / Netlify / Vercel, publish the folder
   containing index.html, style.css and game.js.

CONTROLS
Tap/click an arrow that has an unobstructed path to the board edge.
Use HINT to highlight an available move, Restart to reset, and Next puzzle
to generate a new level.

Files:
- index.html: page structure
- style.css: responsive visual design
- game.js: puzzle logic and level generation
