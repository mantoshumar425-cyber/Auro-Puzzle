const $=id=>document.getElementById(id);
const boardEl=$('board');
const N=7, DIRS=[{x:0,y:-1,ch:'↑',name:'up'},{x:1,y:0,ch:'→',name:'right'},{x:0,y:1,ch:'↓',name:'down'},{x:-1,y:0,ch:'←',name:'left'}];
let level=1,moves=0,cells=[],total=0,best=0;
function idx(x,y){return y*N+x}
function canExit(i,arr=cells){
 const c=arr[i];if(!c||!c.alive)return false;
 let d=DIRS[c.dir],x=c.x+d.x,y=c.y+d.y;
 while(x>=0&&x<N&&y>=0&&y<N){const j=idx(x,y);if(arr[j]&&arr[j].alive)return false;x+=d.x;y+=d.y}
 return true;
}
function generate(){
 moves=0;let count=Math.min(12+Math.floor(level*1.7),34),tries=0;
 while(tries++<100){
  let a=Array(N*N).fill(null),spots=[...Array(N*N).keys()].sort(()=>Math.random()-.5).slice(0,count);
  spots.forEach(i=>{let x=i%N,y=Math.floor(i/N);a[i]={x,y,dir:Math.floor(Math.random()*4),alive:true}});
  let test=a.map(c=>c?{...c}:null),remaining=count,ok=true;
  while(remaining){let found=test.findIndex((c,i)=>c&&c.alive&&canExit(i,test));if(found<0){ok=false;break}test[found].alive=false;remaining--}
  if(ok){cells=a;break}
 }
 if(!cells.length||cells.every(c=>!c)){cells=Array(N*N).fill(null);for(let y=0;y<3;y++)for(let x=0;x<4;x++)cells[idx(x,y)]={x,y,dir:0,alive:true}}
 total=cells.filter(Boolean).length;render();update();
}
function render(){
 boardEl.innerHTML='';
 cells.forEach((c,i)=>{
  const b=document.createElement('button');b.className='tile '+(!c?'empty':(canExit(i)?'free':'blocked'));
  b.setAttribute('aria-label',c?`Arrow ${DIRS[c.dir].name}`:'Empty');
  if(c&&c.alive){const s=document.createElement('span');s.className='arrow';s.textContent=DIRS[c.dir].ch;b.append(s);b.addEventListener('click',()=>tap(i))}
  boardEl.append(b);
 });
}
function tap(i){
 const c=cells[i];if(!c||!c.alive)return;
 if(!canExit(i)){ $('status').textContent='That arrow is blocked — try another';return}
 c.alive=false;moves++;render();update();
 if(cells.filter(Boolean).every(c=>!c.alive)){setTimeout(win,280)}
}
function update(){
 const left=cells.filter(c=>c&&c.alive).length;
 $('level').textContent=level;$('moves').textContent=moves;$('remaining').textContent=`${left} arrows left`;
 $('progressbar').style.width=((total-left)/total*100)+'%';
 $('status').textContent=left?'Find an arrow with a clear path':'Board cleared!';
 $('best').textContent=best?`BEST ${best} MOVES`:'BEST —';
}
function hint(){
 const i=cells.findIndex((c,i)=>c&&c.alive&&canExit(i));
 if(i<0){$('status').textContent='No free arrow — restart this puzzle';return}
 const el=boardEl.children[i];el.animate([{transform:'scale(1)',boxShadow:'0 0 0 0 #5eead400'},{transform:'scale(1.12)',boxShadow:'0 0 0 7px #5eead455'},{transform:'scale(1)'}],{duration:650});
 $('status').textContent='Try the glowing arrow';
}
function win(){if(!best||moves<best)best=moves;$('wintext').textContent=`You cleared ${total} arrows in ${moves} moves.`;$('modal').classList.remove('hidden')}
function next(){level++;$('modal').classList.add('hidden');cells=[];generate()}
$('hint').onclick=hint;$('restart').onclick=()=>{cells=[];generate()};$('newgame').onclick=next;$('continue').onclick=next;
generate();